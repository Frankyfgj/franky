﻿namespace v2rayN.Mode
{
    [Serializable]
    public class RoutingItemModel : RoutingItem
    {
        public bool isActive { get; set; }

    }
}
