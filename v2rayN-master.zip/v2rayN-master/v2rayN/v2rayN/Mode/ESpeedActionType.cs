﻿
namespace v2rayN.Mode
{
    public enum ESpeedActionType
    {
        Ping,
        Tcping,
        Realping,
        Speedtest,
        Mixedtest
    }
}
