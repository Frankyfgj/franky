﻿
namespace v2rayN.Mode
{
    public enum ECoreType
    {
        v2fly = 1,
        Xray = 2,
        SagerNet = 3,
        v2fly_v5 = 4,
        clash = 11,
        clash_meta = 12,
        hysteria = 21,
        naiveproxy = 22,
        tuic = 23,
        sing_box = 24,
        v2rayN = 99
    }
}
