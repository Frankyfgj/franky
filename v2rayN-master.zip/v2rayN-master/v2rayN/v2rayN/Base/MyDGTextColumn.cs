﻿using System.Windows.Controls;

namespace v2rayN.Base
{
    internal class MyDGTextColumn : DataGridTextColumn
    {
        public string ExName { get; set; }

    }
}